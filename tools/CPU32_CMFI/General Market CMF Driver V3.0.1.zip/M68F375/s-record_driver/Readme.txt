This folder contains the driver images in s-record format and a demo illustrating how to use them.

Subdirectories:
1) demo - a demo demonstrating the usage of all driver APIs.
2) gmd_driver - drivers images in s-record format which include .s19 files for all APIs and the data object. 
3) tools - S-Record address relocator utility.
