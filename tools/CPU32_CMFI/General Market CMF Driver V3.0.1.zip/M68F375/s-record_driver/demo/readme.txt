********************************************************************************
                      Readme of GMD Demo for M68F375

                   Software Center, Motorola China
                   
   VERSION:      :  1.0
   DATE          :  April 04, 2001
   AUTHOR        :  Flash Team
********************************************************************************

********************************************************************************
 Motorola reserves the right to make changes without further notice to any
 product herein to improve reliability, function or design. Motorola does not
 assume any liability arising out of the application or use of any product,
 circuit, or software described herein; neither does it convey any license
 under its patent rights nor the rights of others. Motorola products are not
 designed, intended, or authorized for use as components in systems intended for
 surgical implant into the body, or other applications intended to support life,
 or for any other application in which the failure of the  Motorola product
 could create a situation where personal injury or death may occur. Should
 Buyer purchase or use Motorola products for any such unintended or
 unauthorized application, Buyer shall idemnify and hold Motorola and its
 officers, employees, subsidiaries, affiliates, and distributors harmless
 against all claims costs, damages, and expenses, and reasonable attorney fees 
 arising out of, directly or indirectly, any claim of personal injury or death
 associated with such unintended or unauthorized use, even if such claim alleges
 that Motorola was negligent regarding the design or manufacture of the part.
 Motorola and the Motorola logo* are registered trademarks of Motorola Ltd.
********************************************************************************

****************************** CHANGES HISTORY *********************************
  1.0   April 04, 2001	Flash Team      Initial Version
  1.1	April 05, 2001	Cloud Li		Update for m4 configuration
********************************************************************************

1 Overview

This is a demo on General Maket Dirver for M68F375. Usage of all 
GMD APIs are included in it. Detailed features are listed below.

 *) Demonstrate ParallelInit function;
 *) Demonstrate ParallelErase function;
 *) Demonstrate BlankCheck function, involving checking main array and shadow; 
 *) Demonstrate ParallelProgram function, involving programming main array and shadow;
 *) Demonstrate ParallelVerify function, involving Verifying main array and shadow;
 *) Demonstrate CheckSum function,involving calculating main array and shadow;

After the demo has been finished, the result in flash module is listed below:
    main array:
        Module A:	
        Block x 	From 0x00000000 to 0x0000007C : 0x00000000s
        			From 0x00000080 to 0x00007FFC : 0xFFFFFFFFs
        x = 0 ~ 7
        
    shadow:
        Module A is all 0x000000000s.
        

2 GMD Demo for M68F375

2.1 File Structure
s-record_driver (directory)
|
+---demo
|       |demo.scp
|       |init.scp
|       |getstackpointer.scp
|       |asstep.ini
|       |readme.txt 
|       |Shortcut to bdm68k.lnk
|       |clean.bat
|       +cmd
|       |     |ParallelInit.cmd
|       |     |ParallelErase.cmd
|       |     |BlankCheck.cmd
|       |     |ParallelProgram.cmd
|       |     |ParallelVerify.cmd
|       |     |CheckSum.cmd
|		+output
|		|	  |stack.txt
|       +sds_cfg
|       |     |CPU32.dbg
|		+temp
+---gmd_driver
|       |gmd_cpu32_cmf_300_Axx_xxx.s19
|       |gmd_pi.s19
|       |gmd_pe.s19
|       |gmd_bc.s19
|       |gmd_pp.s19
|       |gmd_pv.s19
|       |gmd_cs.s19
|       |gmd.s19
+---tools
|       |build.bat
|       |sar.exe
|  
+---m4src
        |config.bat
        |CPU32.dbg.m4
        |build.bat.m4
        |getercde.com
        |m4.exe
        |util.m4

The above chart is the file set organization of GMD demo for M68F375.
    1) Root directory "s-record_driver" is the working directory;
    2) "Demo" consists of demo case files (*.scp, *.ini, readme.txt and shortcut file);
    3) "gmd_driver" is the directory of GMD Driver file;
    4) "tools" consists of executable files to merge s-record files.
    5) "m4src" consistes of m4 tools and m4 source files(*.m4) for configuration.
            
2.2 Run Demo Manually
2.2.1 Environment
    Windows NT4(sp5), SDS 7.4
    Wiggler on LPT1.
    
2.2.2 Configuration
    1) A batch file is provided to make the normal configuration more easily. The batch 
	file is "config.bat" in the directory "m4src". Note that the batch file will use 
	tools of getercde.com and m4.exe, which are also in the "m4scr" directory.
	Please make sure that the these files exist before using the batch file. 
	
	2) User can select release algorithm, system clock and module mapping. After the configuration,
	the batch file will generate one configuration file: "CPU32.dbg" in the "sds_cfg" directory and 
	one building driver batch file: "build.bat" in the tools directory. 
	"CPU32.dbg" contains SDS script code to initialize the environment and system clock.
	"build.bat" will select GMD and different part descriptor to generate a new GMD in S-record format.
		
	Note: It is recommended that running "config.bat" to configure the environment for the first step.
		  Refer to 2.2.3 for customize new GMD S-record format driver.

2.2.3 Build GMD S-record format driver
	The GMD includes 6 GMD functions and GMD data objects in S-record format and they are also 
	based on offset 0x00000000 in the directory "s-record_driver\gmd_driver". To customize your 
	S-record GMD, you need to :
		a) select the needed GMD functions
		b) change the offsets of the these functions with SAR.EXE
		c) combine these S-record files into one S-record file
	As an example, the "build.bat" in the "tools" directory shows how to build the gmd.s19 
	(in the directory s-record_driver\gmd_driver):
	
	set SAR=sar.exe
	%SAR% ..\gmd_driver\gmd_cpu32_cmf_300_A51_160.s19 temp_io.s19 0x200000
	%SAR% ..\gmd_driver\gmd_pi.s19 temp_pi.s19 0x200400
	%SAR% ..\gmd_driver\gmd_pe.s19 temp_pe.s19 0x200800
	%SAR% ..\gmd_driver\gmd_bc.s19 temp_bc.s19 0x201000
	%SAR% ..\gmd_driver\gmd_pp.s19 temp_pp.s19 0x201400
	%SAR% ..\gmd_driver\gmd_pv.s19 temp_pv.s19 0x201C00
	%SAR% ..\gmd_driver\gmd_cs.s19 temp_cs.s19 0x202000

	copy /B temp_io.s19+temp_pi.s19+temp_pe.s19+temp_bc.s19+temp_pp.s19+temp_pv.s19+temp_cs.s19 ..\gmd_driver\gmd.s19

	del temp*.s19 /q
	
	Note: User can select other part descriptor based on the target and system clock.
	
2.2.4 Procedures of Running Demo Case Manually
In the "demo"directory,"Shortcut to bdm68k.lnk" and "asstep.ini" are
used to run demo manually for M68F375.

    1.Right mouse click on the short cut file, for example 
      "Shortcut to bdm68k.lnk", then select "properties" in the menu, select 
      "shortcut", modify "target" to correct path and right program, and modify
      "start in" to be the same directory as this 
      "Shortcut to bdm68k.lnk" resided.

    2.Launch the shortcut file and switch view to the CMD windows in SDS.
      NOTE:
            The SDS will execute init.scp file to initialize the necessary registers,
            variables, buffer and define the macros.
            
      Run "source demo.scp". Then the demo script will be executed sequentially.       
            
                        
    3.How to perform a specific operation
      The s-record demo uses *.cmd file(s) to perform a specific operation that like 
      the batch file in DOS. The necessary parameters must be set before executing the 
      cmd file.
                                      
      Procedure:      
			FunctionName $para1 $para2 ...
		        
	  FunctionName -- The alias defined in the init.scp indicates the function
      para1        -- The first parameter for the function
      para2        -- The next parameter for the function
      				 		
      There is an example :
      
      Example:( Execute a ParallelErase operation ) (For M68F375)
      
      To perform an operation (such as erase all) you must set some parameters and sent it to 
      the driver, so you may do:
            
            # set cmfPart 
            set cmfPart = $POINTER_OF_CMFPART
            
            # set eraseData
            set eraseData = $POINTER_OF_ERASE_DATA
            
            # set CallBack function pointer
            set CallBack = $POINTER_OF_CALL_BACK
            
            # set BDM FLAG (enter BDM before return)
            write -b $BDM_FLAG=0x01
            
            # set enabledBlocks (erase all blocks)
            write -b $enabledBlocks=0xFF
            
            # call ParallelErase
            ParallelErase $cmfPart $eraseData $enabledBlocks $CallBack
            
         There :
               "set"     	is a SDS command to set variable to specific value;
               "write"   	is a SDS command to write value into given memory location; 
			   "cmfPart" 	is the descriptor of the CMF;
			   "eraseData" 	is the erase algorithm data in the CMF part;
			   "CallBack"	is the CallBack function pointer;
			   "BDM_FLAG"	is a flag which indicates if enter BDM or not before return;
			   "enabledBlocks" indicates the blokcs to be erased;
			   "ParallelErase" is the function name of Parallel Erase
		
		 Note: "cmfPart", "eraseData" and "CallBack" have been defined in the "init.scp", 
		 	   User will take the responsibility if there is any change of these variables.