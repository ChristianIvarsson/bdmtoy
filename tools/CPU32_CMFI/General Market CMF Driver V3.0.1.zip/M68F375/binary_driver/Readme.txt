This folder contains the binary driver images and a demo with programming/erasing time measurement.

Subdirectories:
1) demo - a demo with programming/erasing time (PT) measurement using binary driver images.
2) gmd_driver - binary images for drivers which include .bin files for all APIs and the data object. 
3) gmd_include - header files for applications development.
4) m4src - configuration tools for various clock speeds, programming algorithms and other settings.