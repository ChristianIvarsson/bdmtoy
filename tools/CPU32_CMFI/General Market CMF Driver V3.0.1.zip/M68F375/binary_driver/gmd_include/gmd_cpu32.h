/*************************************************************************
 *           Copyright (C) 2001 by Motorola.  All rights reserved.       *
 *************************************************************************
 *                                                                       *
 *   Motorola reserves the right to make changes without further notice  *
 *   to any product herein to improve reliability, function or design.   *
 *   Motorola does not assume any liability arising out of the           *
 *   application or use of any product, circuit, or software described   *
 *   herein; neither does it convey any license under its patent rights  *
 *   nor the rights of others.                                           *
 *                                                                       *
 *   Motorola products are not designed, intended, or authorized for     *
 *   use as components in systems intended for surgical implant into     *
 *   the body, or other applications intended to support life, or for    *
 *   any other application in which the failure of the Motorola product  *
 *   could create a situation where personal injury or death may occur.  *
 *                                                                       *
 *   Should Buyer purchase or use Motorola products for any such         *
 *   unintended or unauthorized application, Buyer shall idemnify and    *
 *   hold Motorola and its officers, employees, subsidiaries,            *
 *   affiliates, and distributors harmless against all claims costs,     *
 *   damages, and expenses, and reasonable attorney fees arising out     *
 *   of, directly or indirectly, any claim of personal injury or death   *
 *   associated with such unintended or unauthorized use, even if such   *
 *   claim alleges that Motorola was negligent regarding the design      *
 *   or manufacture of the part.                                         *
 *                                                                       *
 *   Motorola and the Motorola logo* are registered trademarks of        *
 *   Motorola Ltd.                                                       *
 *                                                                       *
 *************************************************************************

 *************************************************************************
 *                                                                       *
 *              Motorola's CDR MoneT Flash for CPU32 (CMFI)		         *
 *                          General Market Driver                        *
 *                       CMFI Typedefs & Data Macros                     *
 *                                                                       *
 *     This file contains the CMFI descriptor typedefs and data macros.  *
 *                                                                       *
 * FILE NAME     :  gmd_CPU32.h                                          *
 * DATE          :  Mar 7 2001                                  		 *
 *																		 *
 * AUTHOR        :  Hu Ji                 		                         *
 * EMAIL         :  hooji@sc.mcel.mot.com                                *
 *                                                                       *
 *************************************************************************/

/******************************* CHANGES *********************************
 1.00   2001.03.07		HJ   	Initial Version 
 1.01   2001.03.15		Cloud	Add Cerberus and Sabretooth macro for 
 								CMF_MODULES
 1.02   2001.03.20		HJ		Add Cerberus and Sabretooth macro for 
 								compilling
 								Adjust squence number of macro for return
 								code 
 								Modify data object structure
								Modify CMF_INFO_LOSS_CLOCK to 
								CMF_INFO_LOST_LOCK
 **************************************************************************/

/*--------------------------Return code-------------------------------*/

#define CMF_OK      						0x00

#define CMF_ERROR_SYSCLK_MISMATCH   		0x01
#define CMF_ERROR_PROTECTED_BLOCK	   		0x02
#define CMF_ERROR_SHADOW_RANGE       		0x03
#define CMF_ERROR_ALIGNMENT          		0x04
#define CMF_ERROR_ARRAY_RANGE        		0x05
#define CMF_ERROR_ARRAY_EMR_FAIL   			0x06
#define CMF_ERROR_SHADOW_EMR_FAIL   		0x07
#define CMF_ERROR_ARRAY_PMR_FAIL    		0x08
#define CMF_ERROR_SHADOW_PMR_FAIL   		0x09
#define CMF_ERROR_NOT_BLANK         		0x0A
#define CMF_ERROR_SRC_DEST_VERIFY   		0x0B

/*----------Bit masks for return value of ParallelInit-----------------*/

#define CMF_INFO_STOP   					0x80
#define CMF_INFO_LOCK   					0x40
#define CMF_INFO_PEEM        	  			0x20
#define CMF_INFO_B0EM            			0x10
#define CMF_INFO_INVALID_ARRAY_BASE   		0x08
#define CMF_INFO_LOST_LOCK       			0x04

/*--------------------------Target definition--------------------------*/

#define CERBERUS      				 	1
#define SABRETOOTH			 		 	0

/*----------------------------- Part Specifics ------------------------*/
#if CERBERUS
	#define CMF_MODULES          		1	/* CMF module number of Cerberus	*/
#else													
	#define CMF_MODULES					2	/* CMF module number of Sabretooth	*/ 		
#endif
	
#define MAX_CMF_MODULES          		2   /* maximum CMF module number 		*/
#define MAIN_ARRAY			     		0
#define SHADOW_ROW			    		1
#define CMF_MODULE_A           			0
#define CMF_MODULE_B           			1
#define WORD_SIZE              			4
#define BLOCKS_IN_MODULE		        8
#define TOTAL_BLOCKS           			(CMF_MODULES * BLOCKS_IN_MODULE)
#define PROGRAM_BUFFER_SIZE    			64
#define PAGE_SIZE		    			(PROGRAM_BUFFER_SIZE)
#define SHADOW_SIZE            			0x100
#define SHADOW_ROW_MASK        			0x8080
#define BLOCK_SIZE             			0x8000
#define MODULE_SIZE		                (BLOCKS_IN_MODULE*BLOCK_SIZE)
#define MAX_PAGESET_NUM        			(BLOCK_SIZE/PAGE_SIZE)
#define MAX_PAGESET_NUM_OF_SHADOW       (SHADOW_SIZE/PAGE_SIZE)

/*-------------------------CPU32 Register MASK-------------------------*/

#define CMFMCR_SIE_MASK         		0x2000
#define CMFMCR_LOCK_MASK        		0x0800
#define CMFMCR_PROTECT_MASK     		0x4000
#define CMFMCR_STOP_MASK     			0x8000

#define CMFTST_NVR_PAWS_MASK    		0x0F20

#define CMFCTL_PULSE_WIDTH_MASK 		0x3B7F0000
#define CMFCTL_HVS_MASK         		0x80000000
#define CMFCTL_BLOCKS_MASK      		0x0000FF00
#define CMFCTL_PEEM_MASK        		0x00000020
#define CMFCTL_B0EM_MASK        		0x00000010
#define CMFCTL_PE_MASK          		0x00000004
#define CMFCTL_SES_MASK         		0x00000002
#define CMFCTL_EHV_MASK         		0x00000001

#define CMFBAR_BASE_ADDR_MASK			0x00ffffff

/*----------------------Offset in bytes for GMD IO---------------------*/

#define GMDIO_OFFSET_PART_DESCRIPTION       0
#define GMDIO_OFFSET_PROGRAM_DATA           2
#define GMDIO_OFFSET_ERASE_DATA             4
#define GMDIO_OFFSET_COMP_DATA              6

/*-------------------------- CMF Descriptor ---------------------------*/

typedef struct
{ 
    VUINT16 *cmfMCR;                   	/* pointer to CMFMCR register  */
   	VUINT16 *cmfTST;                    /* pointer to CMFTST register  */
    VUINT32 *cmfCTL;                    /* pointer to CMFCTL1 register */
    									/* and CMFCTL2 register 	   */
    UINT16  cmfMCRInit;               	/* initial value for CMFMCR    */
    UINT16  reserved;					/* reserved for paddding	   */

    UINT32 	arrayBase;                	/* module base address 		   */
    
} tCMF_MODULE;

/*------------------------- Part Definition ---------------------------*/

typedef struct
{
    tCMF_MODULE cmf[CMF_MODULES];   	 /* array of modules structures */
    UINT32 	pulseCnt;                    /* pulse counts for erase      */
                                         /* or whole program pageset    */
    UINT8  	enabledBlocks[CMF_MODULES];  /* array of enabled block flags*/ 
    BOOL  	enableBDM;                   /* enter BDM flag              */
#if CERBERUS
    UINT16 	reserved;					 /* reserved for paddding	   	*/
#else
	UINT8	reserved;					 /* reserved for paddding	   	*/
#endif
} tCMF_PART;


/*--------------------- Program Algorithm Data -------------------------*/

#define CMF_PPS             9          	/* number of program PAWS steps */

typedef struct
{
	UINT16 	regSYNCR;               	/* bitmap of SYNCR register     */
    UINT16 	reserved0;					/* reserved for paddding	   	*/

    UINT32  ctlProg[CMF_PPS];          	/* CMFCTL program timing data   */
    UINT16  pawsProgData[CMF_PPS];     	/* NVR, GDB, & PAWS prog data   */
    UINT16  pawsProgPulses[CMF_PPS];   	/* pulse count per voltage step */

    UINT8   pawsProgMode[CMF_PPS];     	/* program alg mode control     */
    UINT8	reserved1;					/* reserved for paddding	   	*/
    UINT16  maxProgramPulses;          	/* maximum of program pulses    */
} tCMF_PROGRAM_DATA;

/*---------------------- Erase Algorithm Data --------------------------*/

#define CMF_EPS             9       	/* number of erase PAWS steps   */
#define IGNORE_EMR          0x80   		/* ignore erase margin reads    */

typedef struct
{
	UINT16 	regSYNCR;               	/* bitmap of SYNCR register     */
    UINT16 	reserved0;					/* reserved for paddding	   	*/

    UINT32  ctlErase[CMF_EPS];          /* CMFCTL erase timing data     */
    UINT16  pawsEraseData[CMF_EPS];     /* NVR, GDB, & PAWS erase data  */
    UINT16  pawsErasePulses[CMF_EPS];   /* pulse count per voltage step */

    UINT8   pawsEraseMode[CMF_EPS];     /* erase alg mode control       */
    UINT8 	reserved1;					/* reserved for paddding	   	*/
    UINT16  maxErasePulses;             /* maximum  of erase pulses     */
} tCMF_ERASE_DATA;


/*----------------------- Comparison Return Data ------------------------*/

typedef struct
{
    UINT32  failingAddr;				/* Address of the first failing location*/
    UINT32  failingDestData;			/* Current Data in the failing address	*/
    UINT32  failingSourceData;			/* Source data in the failing address	*/
} tCMF_COMP_DATA;

/*------------------------GMD for CPU32: Function pointer prototypes-------------------------*/

typedef tCMF_PART                *pCMF_PART;
typedef tCMF_PROGRAM_DATA        *pCMF_PROGRAM_DATA;
typedef tCMF_ERASE_DATA          *pCMF_ERASE_DATA;
typedef tCMF_COMP_DATA           *pCMF_COMP_DATA;

typedef UINT8 (*pPARALLELINIT)   ( tCMF_PART *cmfPart );
typedef UINT8 (*pPARALLELERASE)  ( tCMF_PART *cmfPart,
                                   tCMF_ERASE_DATA *eraseData,
                                   UINT8 *enabledBlocks,
                                   void (*CallBack)(void) );
typedef UINT8 (*pBLANKCHECK)     ( tCMF_PART *cmfPart,
                                   UINT32 dest,
                                   UINT32 size,
                                   BOOL shadow,
                                   tCMF_COMP_DATA *cmfCompare,
                                   void (*CallBack)(void) );
typedef UINT8 (*pPARALLELPROGRAM)( tCMF_PART *cmfPart,
                                   tCMF_PROGRAM_DATA *programData,
                                   UINT8 *enabledBlocks,
                                   UINT32 source,
                                   UINT32 offset,
                                   UINT16 pagesetNum,
                                   BOOL shadow,
                                   void (*CallBack)(void) );
typedef UINT8 (*pPARALLELVERIFY) ( tCMF_PART *cmfPart,
                                   UINT8 *enabledBlocks,
                                   UINT32 source,
                                   UINT32 offset,
                                   UINT16 pagesetNum,
                                   BOOL shadow,
                                   tCMF_COMP_DATA *cmfCompare,
                                   void (*CallBack)(void) );
typedef UINT8 (*pCHECKSUM)       ( tCMF_PART *cmfPart,
                                   UINT32 dest,
                                   UINT32 size,
                                   BOOL shadow,
                                   UINT8 *sum,
                                   void (*CallBack)(void) );                   