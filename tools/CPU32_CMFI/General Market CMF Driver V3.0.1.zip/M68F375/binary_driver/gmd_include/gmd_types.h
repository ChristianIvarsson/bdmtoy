/*************************************************************************
 *           Copyright (C) 2001 by Motorola.  All rights reserved.       *
 *************************************************************************
 *                                                                       *
 *   Motorola reserves the right to make changes without further notice  *
 *   to any product herein to improve reliability, function or design.   *
 *   Motorola does not assume any liability arising out of the           *
 *   application or use of any product, circuit, or software described   *
 *   herein; neither does it convey any license under its patent rights  *
 *   nor the rights of others.                                           *
 *                                                                       *
 *   Motorola products are not designed, intended, or authorized for     *
 *   use as components in systems intended for surgical implant into     *
 *   the body, or other applications intended to support life, or for    *
 *   any other application in which the failure of the Motorola product  *
 *   could create a situation where personal injury or death may occur.  *
 *                                                                       *
 *   Should Buyer purchase or use Motorola products for any such         *
 *   unintended or unauthorized application, Buyer shall idemnify and    *
 *   hold Motorola and its officers, employees, subsidiaries,            *
 *   affiliates, and distributors harmless against all claims costs,     *
 *   damages, and expenses, and reasonable attorney fees arising out     *
 *   of, directly or indirectly, any claim of personal injury or death   *
 *   associated with such unintended or unauthorized use, even if such   *
 *   claim alleges that Motorola was negligent regarding the design      *
 *   or manufacture of the part.                                         *
 *                                                                       *
 *   Motorola and the Motorola logo* are registered trademarks of        *
 *   Motorola Ltd.                                                       *
 *                                                                       *
 *************************************************************************

 *************************************************************************
 *                                                                       *
 *              Motorola's CDR MoneT Flash for CPU32(CMFI)	             *
 *                          General Market Driver                        *
 *                            CPU32  Typedefs 	                         *
 *                                                                       *
 *     This file contains the register typedefs and macros for the       *
 *     CPU32	 .                                                       *
 *                                                                       *
 * FILE NAME     :  gmd_types.h                                          *
 * DATE          :  Mar 7 2001                                  		 *
 *																		 *
 * AUTHOR        :  Hu Ji                 		                         *
 * EMAIL         :  hooji@sc.mcel.mot.com                                *
 *                                                                       *
 *																		 *
 *************************************************************************/
 

/******************************* CHANGES *********************************
 1.00   3.7.2001   HJ    Initial Version
*************************************************************************/


/****************************** Types ***********************************/

#define FALSE  0
#define TRUE (!FALSE)

typedef unsigned char BOOL;

typedef signed char INT8;
typedef unsigned char UINT8;
typedef volatile signed char VINT8;
typedef volatile unsigned char VUINT8;

typedef signed short INT16;
typedef unsigned short UINT16;
typedef volatile signed short VINT16;
typedef volatile unsigned short VUINT16;

typedef signed long INT32;
typedef unsigned long UINT32;
typedef volatile signed long VINT32;
typedef volatile unsigned long VUINT32;

/************************************************************************/