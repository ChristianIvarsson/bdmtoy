/********************************************************************************************
 *            Serial Communication Functions								                *
 *                                                                                          *
 * File:        SerialComm.c                                                                *
 * Copyright:   Motorola, 2001                                                              *
 ********************************************************************************************/

// *******************************************************************************
// Motorola reserves the right to make changes without further notice to any
// product herein to improve reliability, function or design. Motorola does not
// assume any liability arising out of the application or use of any product,
// circuit, or software described herein; neither does it convey any license
// under its patent rights nor the rights of others. Motorola products are not
// designed, intended, or authorized for use as components in systems  intended for
// surgical implant into the body, or other applications intended to support life,
// or for any other application in which the failure of the  Motorola product
// could create a situation where personal injury or death may occur. Should
// Buyer purchase or use Motorola products for any such unintended or
// unauthorized application, Buyer shall idemnify and hold Motorola and its
// officers, employees, subsidiaries, affiliates, and distributors harmless
// against all claims costs, damages, and expenses, and reasonable attorney fees
// arising out of, directly or indirectly, any claim of personal injury or death
// associated with such unintended or unauthorized use, even if such claim alleges
// that Motorola was negligent regarding the design or manufacture of the part.
// Motorola and the Motorola logo* are registered trademarks of Motorola Ltd.
// ******************************************************************************/

/********************************************************************************************
 * $History: SerialComm.c $
 * 
 * *****************  Version 1  *****************
 * User: Che          Date: 2/14/01    Time: 2:19p
 * Created in $/Internal/Program Time/CMF Parallel Driver V2.3/M68F375/PTDemo
 * Initial version. Identical to those for Sabretooth.
 ********************************************************************************************/

#include "SerialComm.h"

//local function
UINT32 ETAS_outchar(char c);
UINT32 CheckForIOError(UINT32 mode);
void itoa(char* str, UINT32 data);

/************************************************************************
Function	: InitSci (UINT32 brate, UINT32 sysclk)
Parameters	: brate: Baud rate to set
			  sysclk: System clock in MHz
Return		: void
Description	: Initialise SCI1 for receive and transmit, interrupts disabled.
************************************************************************/
void InitSCI (UINT32 brate, UINT32 sysclk)
{
	UINT32 bdata;

	//*****************************
	//  SCI1 Initialization
	//*****************************
	// No Parity, 10-bit Frame(1Start-8Data-1Stop), polling mode. 
	SetRegShort(SCC1R1, 0);

	bdata = (sysclk*1000000)/(brate*32);

	// Use internal system clock to set baud rate
    SetRegShort(SCC1R0, (UINT16)bdata);

	//*****************************
	//  Enable SCI & QSCI
	//*****************************
	OrRegShort(SCC1R1, 0xC);		// TE, RE = 1

	for(bdata=0; bdata<1000; bdata++); 	//wait for serial port stable
}

/************************************************************************
Function	: CheckForIOError(UINT32 mode)
Parameters	: mode: TRANSMIT_MODE or RECEIVE_MODE
Return		: SCI_OK if successful
			  SCI_ERROR otherwise
Description	: check SCI1 IO status
************************************************************************/
UINT32 CheckForIOError(UINT32 mode)
{
	UINT32 loop = 0;
	BOOL done;
	VUINT16 flag;
	do
	{
		flag = *((VUINT16 *) SC1SR) & 0xFF;
		//Check for: Overrun, Noise Error, Framing Error, and Parity Error
		if ((flag & 0xF) != 0)
		{
			//To clear the flag, read the status and then read or write the data register
			flag = *((VUINT16 *) SC1SR) & 0xFF;
			flag = *((VUINT16 *) SC1DR); //Clear the flag 
			return SCI_ERROR;
		}
		if (mode == TRANSMIT_MODE)
			done = (BOOL)((flag & 0x80) != 0);
		else
			done = (BOOL)((flag & 0x20) == 0);
	} while ((!done) && (loop++ < 1000)); 
	
	return SCI_OK;
}

/************************************************************************
Function	: ETAS_outchar(char c)
Parameters	: char c: character to send
Return		: SCI_OK if successful
			  SCI_ERROR otherwise
Description	: send out a character to serial port
************************************************************************/
UINT32 ETAS_outchar(char c)
{
	UINT32 loop = 0;

	if (IsTransmitter1Idle() == 0)
		return SCI_ERROR;
		
	while ((!IsTransmitter1Ready()) && (loop++ < 1000)); 

	if(loop >= 1000)
		return SCI_ERROR;

	SendCharToTransmitter1(c);
	// Wait till the data is sent (check if the transmitter is still busy).
	// Check also for IO Error.
	// It is necessary so that the next time we get into _outchar
	// and detected the transmitter is still busy, then something is wrong.
	return (CheckForIOError(TRANSMIT_MODE));
}

/************************************************************************
Function	: PrintStr(const char* tx_buf)
Parameters	: string to send out
Return		: SCI_OK if successful
			  SCI_ERROR otherwise
Description	: send out a character string to serial port
************************************************************************/
UINT32 PrintStr(const char* tx_buf)
{
	UINT32 i = 0;

    while(tx_buf[i] != '\0')
	{
		if(ETAS_outchar(tx_buf[i]) == SCI_ERROR)
			return SCI_ERROR;
		i++;
	}

	return SCI_OK;
}

/************************************************************************
Function	: itoa(char* str, UINT32 data)
Parameters	: str: string to store the conversion result
			  data: 32-bit integer to convert
Return		: None
Description	: Convert a 32-bit integer to ASCII string
************************************************************************/
void itoa(char* str, UINT32 data)
{
	UINT32 temp;
	UINT8  bits = 0;
	UINT8  i;

	//get the number of bits in the integer
	if(data == 0)
		bits = 1;
	else
	{
		temp = data;
		while(temp!=0)
		{
			temp = temp/10;
			bits++;
		}
	}	 
	for(i=0; i<bits; i++)
	{
		str[bits-1-i] = '0' + (char)(data%10); //get the char corresponding to the bit
		data = data/10;
	}
	str[bits] = '\0';		//end the string
}

/************************************************************************
Function	: PrintInt(UINT32 data)
Parameters	: data: 32-bit integer to print on hyperterm
Return		: SCI_OK if successful
			  SCI_ERROR otherwise
Description	: print a 32-bit integer on hyperterm
************************************************************************/
UINT32 PrintInt(UINT32 data)
{
	char str[32];
	itoa(str, data);
	return (PrintStr(str));	
}