/******************************************************************************
 *                                                                            *
 *           Copyright (C) 2000 by Motorola.  All rights reserved.            *
 *                                                                            *
 ******************************************************************************
/******************************************************************************
 Motorola reserves the right to make changes without further notice to any
 product herein to improve reliability, function or design. Motorola does not
 assume any liability arising out of the application or use of any product,
 circuit, or software described herein; neither does it convey any license
 under its patent rights nor the rights of others. Motorola products are not
 designed, intended, or authorized for use as components in systems intended for
 surgical implant into the body, or other applications intended to support life,
 or for any other application in which the failure of the  Motorola product
 could create a situation where personal injury or death may occur. Should
 Buyer purchase or use Motorola products for any such unintended or
 unauthorized application, Buyer shall idemnify and hold Motorola and its
 officers, employees, subsidiaries, affiliates, and distributors harmless
 against all claims costs, damages, and expenses, and reasonable attorney fees 
 arising out of, directly or indirectly, any claim of personal injury or death
 associated with such unintended or unauthorized use, even if such claim alleges
 that Motorola was negligent regarding the design or manufacture of the part.
 Motorola and the Motorola logo* are registered trademarks of Motorola Ltd.
 ******************************************************************************/

/*******************************************************************************
	History
 	1/12/2000	Chen He		Created
 	30/3/2001	Cloud Li	Update for GMD 375
********************************************************************************/

#ifndef __TIMELIB_H_
#define __TIMELIB_H_

#include "gmd_types.h"

#define UINT32_MAX	   ((UINT32)(0xffffffff))
#define UINT16_MAX	   ((UINT32)(0xffff))


typedef struct _sTimerInfo {
	UINT32	tcnt;		//timer count
	UINT32  ofl;		//overflow 
} TimerInfo;			 

//timing function prototypes
void TimerInit(UINT32 ClkDiv);
void ResetTimer(void);
TimerInfo GetTimer(void);
UINT32 GetElapseTime(UINT32 ClkDiv, UINT32 SysClk);

#endif

