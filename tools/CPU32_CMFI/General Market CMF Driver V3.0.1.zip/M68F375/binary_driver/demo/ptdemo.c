/*************************************************************************
 *           Copyright (C) 2001 by Motorola.  All rights reserved.       *
 *************************************************************************
 *                                                                       *
 *   Motorola reserves the right to make changes without further notice  *
 *   to any product herein to improve reliability, function or design.   *
 *   Motorola does not assume any liability arising out of the           *
 *   application or use of any product, circuit, or software described   *
 *   herein; neither does it convey any license under its patent rights  *
 *   nor the rights of others.                                           *
 *                                                                       *
 *   Motorola products are not designed, intended, or authorized for     *
 *   use as components in systems intended for surgical implant into     *
 *   the body, or other applications intended to support life, or for    *
 *   any other application in which the failure of the Motorola product  *
 *   could create a situation where personal injury or death may occur.  *
 *                                                                       *
 *   Should Buyer purchase or use Motorola products for any such         *
 *   unintended or unauthorized application, Buyer shall idemnify and    *
 *   hold Motorola and its officers, employees, subsidiaries,            *
 *   affiliates, and distributors harmless against all claims costs,     *
 *   damages, and expenses, and reasonable attorney fees arising out     *
 *   of, directly or indirectly, any claim of personal injury or death   *
 *   associated with such unintended or unauthorized use, even if such   *
 *   claim alleges that Motorola was negligent regarding the design      *
 *   or manufacture of the part.                                         *
 *                                                                       *
 *   Motorola and the Motorola logo* are registered trademarks of        *
 *   Motorola Ltd.                                                       *
 *                                                                       *
 *************************************************************************

 *************************************************************************
 *                                                                       *
 *              Motorola's CDR MoneT Flash for CPU32 (CMFI)              *
 *                          General Market Driver                        *
 *                  GMD erase and program measurement demo		 		 *
 *                                                                       *
 * FILE NAME     :  ptdemo.c                                             *
 * VERSION:      :  0.10                                                 *
 * DATE          :  22 March 2001	                                     *
 *                                                                       * 
 *************************************************************************/

/*********************************************************************************************
1. Demo for measuring erase and program time.
2. This demo only use ParallelInit, ParallelErase and ParallelProgram driver:
	GMD data objects (including part description, program algorithm data, erase 
	algorithm data and compara object: 
	Gmd_cpu32_cmf_300_Axx_xxx.bin
	ParallelInit	gmd_pi.bin
	ParallelErase	gmd_pe.bin
	ParallelProgram gmd_pp.bin

	These binary images will be loaded into memory by "load_gmd.scp" file.
	The following memmory map table outlines where the GMD binaries and demo are.
	Note that all the binary images should start from word (4-bytes) boundary.
	In the demo, the reserved RAM for each binary image is larger than the actual
	size. 

									Start Address	End Address		Size
	-----------------------------------------------------------------------------------
	GMD driver and data objects		0x200000		0x201800-1		6K bytes  (0x1800)
	
		GMD data objects			0x200000		0x200400-1		1K bytes  (0x400)
		ParallelInit				0x200400		0x200800-1		1K bytes  (0x400)
		ParallelErase				0x200800		0x201000-1		2K bytes  (0x800)
		ParallelProgram				0x201000		0x201800-1		2K bytes  (0x800)
	
	Demo and crt0.s					0x201800		0x203C00-1		9K bytes  (0x2400)
	
	Stack							0x203C00		0x204000-1		1K bytes  (0x400)

3. Please follow the below steps to run the demo:
	compile the demo code
	start SDS
	load GMD (type "source load_gmd.scp" in the command window)
	run demo
*********************************************************************************************/

/******************************* CHANGES **************************************
 0.1.0	2001.03.22  Flash Team		Initial version
 0.1.1	2001.03.27	Flash Team 		Update for the program and erase time 
 									measurement. ( PT DEMO )
 0.1.2  2001.04.05	Flash Team 		Added numRuns for multiple runs 									
 ******************************************************************************/
#include <gmd_types.h>
#include <gmd_CPU32.h>
#include <TimeLib.h>
#include <ptdemo.h>

#if SERIAL_DISPLAY
#include <SerialComm.h>
#endif

EraseTimeResults eraseTiming;	// timing results for erase 
ProgTimeResults progTiming;		// timing results for program 

UINT32 numRuns = 1; 			// # of times to run this demo
								// Note: modify this variable at run time in SDS if multiple runs preferred	

void CallBack( void );


UINT8 main(void)
{
    pCMF_PART           cmfPart         = (pCMF_PART)         0;
    pCMF_ERASE_DATA     eraseData       = (pCMF_ERASE_DATA)   0;
    pCMF_PROGRAM_DATA   programData     = (pCMF_PROGRAM_DATA) 0;

	// GMD data object
	UINT32* CPU32CMF300					= (UINT32*)			  0x200000; 	
    pPARALLELINIT       ParallelInit    = (pPARALLELINIT)     0x200400;
    pPARALLELERASE      ParallelErase   = (pPARALLELERASE)    0x200800;
    pPARALLELPROGRAM    ParallelProgram = (pPARALLELPROGRAM)  0x201000;

    UINT16 *gmd_data = (UINT16*) CPU32CMF300;

    UINT8   enabledBlocks[CMF_MODULES];
    
    // defined as volatile variable for avoiding being optimized and user can see it in debug mode
    VUINT8  returnCode; 

    UINT32  buffer[TOTAL_BLOCKS*PAGE_SIZE/4];   // source program buffer, size = 8(blocks) * 16(page size in word) * 1 (pagesets)
    UINT32  i, k;

	UINT32 pageTime, pagePulse;
                    
   	// anchor data objects from GMD Data Object
    if(gmd_data[GMDIO_OFFSET_PART_DESCRIPTION/2] != 0xFFFF)
        cmfPart = (pCMF_PART) ((UINT32)CPU32CMF300 + gmd_data[GMDIO_OFFSET_PART_DESCRIPTION/2]);

    if(gmd_data[GMDIO_OFFSET_PROGRAM_DATA/2] != 0xFFFF)
        programData = (pCMF_PROGRAM_DATA) ((UINT32)CPU32CMF300 + gmd_data[GMDIO_OFFSET_PROGRAM_DATA/2]);

    if(gmd_data[GMDIO_OFFSET_ERASE_DATA/2] != 0xFFFF)
        eraseData = (pCMF_ERASE_DATA) ((UINT32)CPU32CMF300 + gmd_data[GMDIO_OFFSET_ERASE_DATA/2]);

	// initialize SCI module
#if SERIAL_DISPLAY
	InitSCI (9600, SYSTEM_CLK_MHZ);		//set serial port baud rate to 9600
	returnCode = (VUINT8)PrintStr("\n\rCerberus (M68F375) PT Demo start.\n\r");
	if(returnCode != SCI_OK)
	   	return returnCode;
#endif

    /*========================= Initialize part ============================*/
    cmfPart->enabledBlocks[CMF_MODULE_A] = 0xFF;	// enable all Blocks in module A
    
    cmfPart->enableBDM = FALSE;                 	// don't enter BDM after func exit
   

	for(k=0; k<numRuns; k++)
	{
		/*========================= Initialize timer =======================*/
	    TimerInit( TIMER_CLK_DIVIDER );
	
		/*========================= Check for environment ==================*/
	    // call ParallelInit
	    returnCode = (*ParallelInit)( cmfPart );
	    if(returnCode != CMF_OK)
			return ( returnCode );
	
	
	    /*==================Erase all blocks and shadow row=================*/
#if SERIAL_DISPLAY
		PrintStr("\n\rErasing");
#endif
	    
	    // enable all blocks and shadow
	    enabledBlocks[CMF_MODULE_A] = 0xFF;
	    
		// reset timer here
		ResetTimer();
	
	    // ParallelErase(cmfPart, eraseData, enabledBlocks, CallBack );
	    returnCode = (*ParallelErase)( cmfPart, eraseData, enabledBlocks, CallBack );
	    if(returnCode != CMF_OK) 
			return ( returnCode );
			
		// get erase time
		eraseTiming.time = GetElapseTime(TIMER_CLK_DIVIDER, SYSTEM_CLK_MHZ) / 100;  // milliseconds*10
		eraseTiming.pulse = cmfPart->pulseCnt;
	
#if SERIAL_DISPLAY
		PrintStr("\n\rErase Timing Results (time in millisec*10):\n\r");
		PrintStr("Time \t Pulse \n\r");
		PrintInt(eraseTiming.time);  PrintStr("\t");
		PrintInt(eraseTiming.pulse); PrintStr("\n\r");
#endif
	
	    /*======Program all main arrays to 0s================*/
#if SERIAL_DISPLAY
		PrintStr("\n\rProgramming\n\r");
#endif
	
	    // initialize the source buffer for program, set them all to 0s
	    for( i = 0; i < TOTAL_BLOCKS * (PAGE_SIZE / 4); i++)
	        buffer[i]=0x00000000;   // set source buffer to all 0s
	
	    // select all blocks in module A to be programmed
	    enabledBlocks[CMF_MODULE_A] = 0xFF;
	
		//initialize the result structure
		progTiming.totalTime = 0;
		progTiming.totalPulse = 0;
		progTiming.minPageTime = UINT32_MAX;
		progTiming.minPagePulse = UINT32_MAX;
		progTiming.maxPageTime = 0;
		progTiming.maxPagePulse = 0;
		
	    // program all cmf array of module A from 0xFFFFFFFF to 0x00000000 (call ParallelProgram 512 times, one pageset each time)
	    for(i = 0; i < MAX_PAGESET_NUM; i++)
	    {
			// reset timer for programming
			ResetTimer();
			
	        // ParalleProgram( cmfPart, programData, enabledBlocks, (UINT32)source, offset, pagesetNum, shadow, CallBack );
	        returnCode = (*ParallelProgram)( cmfPart, programData, enabledBlocks, (UINT32)buffer, PAGE_SIZE*i, 1, MAIN_ARRAY, CallBack );
	        if(returnCode!=CMF_OK)
	            return ( returnCode );
			
			// get the pageset program time and pulse count
			pageTime = GetElapseTime(TIMER_CLK_DIVIDER, SYSTEM_CLK_MHZ) / 100;  	//milliseconds*10
			pagePulse = cmfPart->pulseCnt;
	
			// get the min/max pageset program pulse count 
			if(pagePulse > progTiming.maxPagePulse)
				progTiming.maxPagePulse = pagePulse;
			if(pagePulse < progTiming.minPagePulse)
				progTiming.minPagePulse = pagePulse;
			// get the min/max pageset program time			
			if(pageTime > progTiming.maxPageTime)
				progTiming.maxPageTime = pageTime;
			if(pageTime < progTiming.minPageTime)
				progTiming.minPageTime = pageTime;
	
			// accumulate to get the total program time and pulse count
			progTiming.totalTime += pageTime;
			progTiming.totalPulse += pagePulse;
	
#if SERIAL_DISPLAY
			PrintStr(".");
#endif
	            
	    }
	
		// calculate average pageset program time and pulse count
		progTiming.avePageTime = progTiming.totalTime / MAX_PAGESET_NUM;
		progTiming.avePagePulse = progTiming.totalPulse / MAX_PAGESET_NUM;
	
		// convert total program time to seconds
		//progTiming.totalTime =  progTiming.totalTime / 10000;    
	
#if SERIAL_DISPLAY
		PrintStr("\n\r\n\rParallel Program time (in millisec*10):\n\r");
		PrintStr("Time \t Pulse \t MinPT \t MaxPT \t AvePT \t MinPP \t MaxPP \t AvePP\n\r"); 
		PrintInt(progTiming.totalTime);  PrintStr("\t");
		PrintInt(progTiming.totalPulse); PrintStr("\t");
		PrintInt(progTiming.minPageTime); PrintStr("\t");
		PrintInt(progTiming.maxPageTime); PrintStr("\t");
		PrintInt(progTiming.avePageTime); PrintStr("\t");
		PrintInt(progTiming.minPagePulse); PrintStr("\t");
		PrintInt(progTiming.maxPagePulse); PrintStr("\t");
		PrintInt(progTiming.avePagePulse); PrintStr("\n\r");
#endif
    
	}//end loop for runs
           
    // DEMO PASSED  
    return DEMO_PASS;
}


void CallBack( void )
{
}
