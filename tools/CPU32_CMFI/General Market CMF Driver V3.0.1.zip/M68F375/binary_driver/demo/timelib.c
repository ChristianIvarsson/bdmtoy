/******************************************************************************
 *                                                                            *
 *           Copyright (C) 2000 by Motorola.  All rights reserved.            *
 *                                                                            *
 *						1/12/2000	Chen He		Created						  *
 ******************************************************************************
/******************************************************************************
 Motorola reserves the right to make changes without further notice to any
 product herein to improve reliability, function or design. Motorola does not
 assume any liability arising out of the application or use of any product,
 circuit, or software described herein; neither does it convey any license
 under its patent rights nor the rights of others. Motorola products are not
 designed, intended, or authorized for use as components in systems intended for
 surgical implant into the body, or other applications intended to support life,
 or for any other application in which the failure of the  Motorola product
 could create a situation where personal injury or death may occur. Should
 Buyer purchase or use Motorola products for any such unintended or
 unauthorized application, Buyer shall idemnify and hold Motorola and its
 officers, employees, subsidiaries, affiliates, and distributors harmless
 against all claims costs, damages, and expenses, and reasonable attorney fees 
 arising out of, directly or indirectly, any claim of personal injury or death
 associated with such unintended or unauthorized use, even if such claim alleges
 that Motorola was negligent regarding the design or manufacture of the part.
 Motorola and the Motorola logo* are registered trademarks of Motorola Ltd.
 ******************************************************************************/

/*******************************************************************************
 *	$History: TimeLib.c $
 * 
 * *****************  Version 4  *****************
 * User: Che          Date: 2/01/01    Time: 4:03p
 * Updated in $/Internal/Program Time/CMF Parallel Driver V2.3/M68F375/PTDemo
 * add VSS header
 * 
 * *****************  Version 3  *****************
 * User: Che          Date: 2/01/01    Time: 3:57p
 * Updated in $/Internal/Program Time/CMF Parallel Driver V2.3/M68F375/PTDemo
 * Clear counter before clear overflow flag to make sure no overflow will
 * happen during read/write operation. Also, check overflow flag twice to
 * make sure getting consistent pair of values of counter and overflow
 * flag.
********************************************************************************/

#include "gmd_types.h"
#include "TimeLib.h"

// Registers definition for timing
VUINT16 *CPCR    = (UINT16 *)0xFFF208;      // CPCR - CPSM CONTROL REGISTER ( Address : 0xFFF208 )
VUINT16 *FMSMSIC = (UINT16 *)0xFFF260;      // FCSM status/interrupt/control register ( Address : 0xfff260 )
VUINT16 *FCSMCNT = (UINT16 *)0xFFF262;      // FCSM counter register ( Address : 0xfff262 )



// Local function prototypes
UINT32 CheckOverflow(void);

/******************************************************************************
 * Function    : ResetTimer(void)                                             *
 * Parameters  : None                                                         *
 * Return      : NoneL.					                                      *
 * Description : Reset timer and clear overflow flag.						  *
 ******************************************************************************/
void ResetTimer(void)
{
    *FCSMCNT = 0;					// Clear counter prior to clear the overflow flag	
    *FMSMSIC &= 0x7FFF;             // Clear overflow flag
    *FCSMCNT = 0;                   // Clear counter
}


/******************************************************************************
 * Function    : CheckOverflow(void)                                          *
 * Parameters  : None                                                         *
 * Return      : 0: no overflow occured, 1: timer overflow occured.           *
 * Description : Check Counter overflow flag in FCSMSIC.                      *
 ******************************************************************************/
UINT32 CheckOverflow(void)
{
    return (UINT32)( *FMSMSIC >> 15 );
}

/******************************************************************************
 * Function    : TimerInit(UINT32 ClkDiv)                                     *
 * Parameters  : ClkDiv: Timer clock divider                                  *
 * Return      : None                                                         *
 * Description : Initialize timing regs.                                      *
 ******************************************************************************/
void TimerInit(UINT32 ClkDiv)
{                                           
    // Config the prescaler and Init. control register 
	switch(ClkDiv)
	{
		case 2:	   //first prescaler /2 -> DIV23 = 0
			*CPCR	= 0x0000;	
			*FMSMSIC= 0x0000;
			break;
		case 4:
			*CPCR	= 0x0000;	
			*FMSMSIC= 0x0001;
			break;
		case 8:
			*CPCR	= 0x0000;	
			*FMSMSIC= 0x0002;
			break;
		case 16:
			*CPCR	= 0x0000;	
			*FMSMSIC= 0x0003;
			break;
		case 32:
			*CPCR	= 0x0000;	
			*FMSMSIC= 0x0004;
			break;
		case 64:	
			*CPCR	= 0x0000;	
			*FMSMSIC= 0x0005; //PCLK6
			break;
		case 128:
			*CPCR	= 0x0001;	
			*FMSMSIC= 0x0005; //PCLK6
			break;
		case 256:
			*CPCR	= 0x0002;	
			*FMSMSIC= 0x0005; //PCLK6
			break;
		case 512:
			*CPCR	= 0x0003;	
			*FMSMSIC= 0x0005; //PCLK6
			break;
		case 3:		//first prescaler /3 -> DIV23 = 1
			*CPCR	= 0x0004;	
			*FMSMSIC= 0x0000;
			break;
		case 6:
			*CPCR	= 0x0004;	
			*FMSMSIC= 0x0001;
			break;
		case 12:
			*CPCR	= 0x0004;	
			*FMSMSIC= 0x0002;
			break;
		case 24:
			*CPCR	= 0x0004;	
			*FMSMSIC= 0x0003;
			break;
		case 48:
			*CPCR	= 0x0004;	
			*FMSMSIC= 0x0004;
			break;
		case 96:
			*CPCR	= 0x0004;	
			*FMSMSIC= 0x0005; //PCLK6
			break;
		case 192:
			*CPCR	= 0x0005;	
			*FMSMSIC= 0x0005; //PCLK6
			break;
		case 384:
			*CPCR	= 0x0006;	
			*FMSMSIC= 0x0005; //PCLK6
			break;
		case 768:
			*CPCR	= 0x0007;	
			*FMSMSIC= 0x0005; //PCLK6
			break;			
		default:
		    *CPCR   = 0x0003;  // DIV = 2, devide Fsys by 2, PSEL[1:0] = 11 (256)
	    	                    // PCLK = (Fsys/2)/256
	        	                // Select 512 prescaler
		    *FMSMSIC= 0x0005;  // Select prescaler output 6, clear overflow flag, no interrupt
	}

    *CPCR   |= 0x0008;  // Start Timer
}

/******************************************************************************
 * Function    : GetTimer(void)                                               *
 * Parameters  : None                                                         *
 * Return      : Current value in TimerInfo structure.                        *
 * Description : Getting the current 16-bit counter and overflow flag.        *
 ******************************************************************************/
TimerInfo GetTimer(void)
{
	TimerInfo curTime;
	
	curTime.ofl = CheckOverflow();	
    curTime.tcnt = ((UINT32)*FCSMCNT);

	if(curTime.ofl != CheckOverflow()) //overflow happens during the above two reads
	{
		curTime.tcnt = UINT16_MAX; //set tcnt to max, and keep overflow flag clear
	}

	return (curTime);
}

/******************************************************************************
 * Function    : GetElapseTime(UINT32 ClkDiv, UINT32 SysClk) *
 * Parameters  : ClkDiv - Timer clock divider								  *
 *				 SysClk	- System clock frequency in MHz						  *
 * Return      : Time in microsecondes.			                              *
 * Description : Calculate elapsed time										  *
 ******************************************************************************/
UINT32 GetElapseTime(UINT32 ClkDiv, UINT32 SysClk)
{
	TimerInfo end = GetTimer();
	UINT32 elapseTime;

	if(!end.ofl) //no overflow
	{
		elapseTime = end.tcnt * ClkDiv / SysClk;
	}
	else	//overflows
	{
		elapseTime = (UINT16_MAX + end.tcnt) * ClkDiv / SysClk;
	}
	return(elapseTime);
}

