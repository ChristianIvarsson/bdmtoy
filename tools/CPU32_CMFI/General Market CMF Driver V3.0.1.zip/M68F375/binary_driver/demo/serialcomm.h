/********************************************************************************************
 *            Serial Communication Functions								                *
 *                                                                                          *
 * File:        SerialComm.h                                                                *
 * Copyright:   Motorola, 2001                                                              *
 ********************************************************************************************/

// *******************************************************************************
// Motorola reserves the right to make changes without further notice to any
// product herein to improve reliability, function or design. Motorola does not
// assume any liability arising out of the application or use of any product,
// circuit, or software described herein; neither does it convey any license
// under its patent rights nor the rights of others. Motorola products are not
// designed, intended, or authorized for use as components in systems  intended for
// surgical implant into the body, or other applications intended to support life,
// or for any other application in which the failure of the  Motorola product
// could create a situation where personal injury or death may occur. Should
// Buyer purchase or use Motorola products for any such unintended or
// unauthorized application, Buyer shall idemnify and hold Motorola and its
// officers, employees, subsidiaries, affiliates, and distributors harmless
// against all claims costs, damages, and expenses, and reasonable attorney fees
// arising out of, directly or indirectly, any claim of personal injury or death
// associated with such unintended or unauthorized use, even if such claim alleges
// that Motorola was negligent regarding the design or manufacture of the part.
// Motorola and the Motorola logo* are registered trademarks of Motorola Ltd.
// ******************************************************************************/

/********************************************************************************************
 * $History: SerialComm.h $
 * 
 * *****************  Version 1  *****************
 * User: Che          Date: 2/14/01    Time: 2:19p
 * Created in $/Internal/Program Time/CMF Parallel Driver V2.3/M68F375/PTDemo
 * Initial version. Identical to those for Sabretooth.
 ********************************************************************************************/

#ifndef __CPU32_SERIAL_COMM_H
#define __CPU32_SERIAL_COMM_H

#include "gmd_types.h"

//QSMCM base address
#define SCI_BASE 0xFFFC00  

#define SCC1R0		(SCI_BASE + 0x8)
#define SCC1R1		(SCI_BASE + 0xA)
#define SC1SR		(SCI_BASE + 0xC)
#define SC1DR		(SCI_BASE + 0xE)
#define SCC2R0		(SCI_BASE + 0x20)
#define SCC2R1		(SCI_BASE + 0x22)
#define SC2SR		(SCI_BASE + 0x24)
#define SC2DR		(SCI_BASE + 0x26)
#define QSCI1CR		(SCI_BASE + 0x28)
#define QSCI1SR		(SCI_BASE + 0x2A)

#define IsTransmitter1Ready()   (*((VUINT16 *) SC1SR) & 0x100)
#define IsTransmitter1Idle()	(*((VUINT16 *) SC1SR) & 0x80)
#define IsReceiver1Full()		(*((VUINT16 *) SC1SR) & 0x40)
#define IsReceiver1Busy()		(*((VUINT16 *) SC1SR) & 0x20)
#define SetRegLong(ptr, value)  (*((VUINT32 *) ptr) = value)
#define SetRegShort(ptr, value)  (*((VUINT16 *) ptr) = value)
#define OrRegLong(ptr, value)   (*((VUINT32 *) ptr) |= value)
#define OrRegShort(ptr, value)   (*((VUINT16 *) ptr) |= value)
#define AndRegLong(ptr, value)   (*((VUINT32 *) ptr) &= value)
#define AndRegShort(ptr, value)   (*((VUINT16 *) ptr) &= value)
#define SendCharToTransmitter1(c)	(*((VUINT16 *) SC1DR) = c)
#define GetCharFromTransmitter1()	((UINT8) *((VUINT16 *) SC1DR))

#define TRANSMIT_MODE 0
#define RECEIVE_MODE  1

//return values
#define SCI_ERROR				1
#define SCI_OK					0

//APIs
void InitSCI (UINT32 brate, UINT32 sysclk);	 
UINT32 PrintStr(const char* tx_buf);
UINT32 PrintInt(UINT32 data);

#endif
