/******************************************************************************
 *                                                                            *
 *           Copyright (C) 2001 by Motorola.  All rights reserved.            *
 *                                                                            *
 ******************************************************************************
/******************************************************************************
 Motorola reserves the right to make changes without further notice to any
 product herein to improve reliability, function or design. Motorola does not
 assume any liability arising out of the application or use of any product,
 circuit, or software described herein; neither does it convey any license
 under its patent rights nor the rights of others. Motorola products are not
 designed, intended, or authorized for use as components in systems intended for
 surgical implant into the body, or other applications intended to support life,
 or for any other application in which the failure of the  Motorola product
 could create a situation where personal injury or death may occur. Should
 Buyer purchase or use Motorola products for any such unintended or
 unauthorized application, Buyer shall idemnify and hold Motorola and its
 officers, employees, subsidiaries, affiliates, and distributors harmless
 against all claims costs, damages, and expenses, and reasonable attorney fees 
 arising out of, directly or indirectly, any claim of personal injury or death
 associated with such unintended or unauthorized use, even if such claim alleges
 that Motorola was negligent regarding the design or manufacture of the part.
 Motorola and the Motorola logo* are registered trademarks of Motorola Ltd.
 ******************************************************************************/

/****************************** CHANGES HISTORY *******************************
  1.0   Jan. 19, 2001   Chen He         Initial Version
  2.0   Mar. 30, 2001   Cloud Li		Remove return values macro for TRD
  3.0	Mar. 30, 2001	Cloud Li		Update for GMD 372  
******************************************************************************/

#ifndef _PTDEMO_H_
#define _PTDEMO_H_

// Display status and results in HyperTerm via serial port
#define SERIAL_DISPLAY				0

// System clock divider for timer clock
#define TIMER_CLK_DIVIDER			512	

// System clock frequency in 16 MHz
#define SYSTEM_CLK_MHZ				16

//  Contants
#define DRIVER_BASE_ADDR    		0x200000

//default system clock is 16 MHz
#define DEFAULT_SYSCLK				16 		

#define DEMO_PASS                   0

typedef struct _sProgTimeResults {
	UINT32  totalTime;		//total program time (ms*10)
	UINT32  totalPulse;		//total program pulse count
	UINT32	minPageTime;	//min pageset program time (ms*10)
	UINT32  maxPageTime;	//max pageset program time (ms*10)
	UINT32  avePageTime;	//average pageset program time (ms*10)
	UINT32  minPagePulse;	//min pageset program pulse cnt
	UINT32  maxPagePulse;	//max pageset program pulse cnt
	UINT32 	avePagePulse;	//average pageset program pulse cnt
} ProgTimeResults;			 

typedef struct _sEraseTimeResults {
	UINT32  time;			//total erase time (ms*10)
	UINT32  pulse;			//total erase pulse count
} EraseTimeResults;

#endif  //_PTDEMO_H_
