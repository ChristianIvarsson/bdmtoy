Programming Time Demo for General Maket Driver V3.0.0 ReadMe
MC68F375
==============================================================================

This folder contains programming time demo using binary image driver.
This demo will capture the min, max and average program time and pulse count 
per pageset in addition to total program time and pulse count.

For an immediate source-level debugging session, just load the prebuilt ELF
file with your debugger, and then run load_gmd.scp in SDS command window to load
the corresponding binary driver.

TIPS:
- How to run SDS script to load the binary GMD images:
In SDS, open Command window, type the following command:
	source load_gmd.scp
- How to start SDS:
There is a shortcut to SDS in the directory "Demo" and before running it,
please make sure its property is set as follows: "target" should point to the 
SDS system directory in your machine and "Start in" should be the directory 
of "Demo".


Features:

1. Easy Configuration

A batch file is provided to make the normal configuration more easily. The batch 
file is "config.bat" in the directory "m4src". Note that the batch file will use 
tools of getercde.com and m4.exe, which are also in the "m4scr" directory.
Please make sure that the these files exist before using the batch file. 

Enter the directory "m4src" and run the "config.bat", there are five menues to 
select the basic configurations:

1) Algorithm 5.0/5.1/6.0/6.1 selection: Algorithm 5.0 is only for CMF5 parts
and 5.1 is for CMF5 TTO part; 6.0 and 6.1 is for CMF release 6 and above.

2) System Clock selection: select the system clock the system will be running at.

3) Timing Counter Clock Division Ratio selection: select the division ratio for the
counter clock. The counter clock frequency will be the system clock frequency divided
by the division ratio. For instance, if system clock is 32MHz and the division ratio 
selected is 64, then the counter clock frequency is 0.5MHz, which means one counter
tick is 2 microseconds. 

TIPS:
Due to hardware limitations that only one overflow can be handled, the maximum period PT demo 
can measure is 2*64K*CounterTick.        
So there is a trade-off between resolution and being in range. Below is a general rule:
For time measurement requires high accuary such as in microseconds, use small division ratio.
For time measurement requires low accuary such as in milliseconds,  use large division ratio.

4) Enable/Disable Serial Port Display selection: if serial port display is enabled, 
programming status and timing results will be sent to RS232 port on EVB board and 
displayed on Hyperterminal, provided Hyperterminal with correct settings is invoked. 

5) Module Mapping Selection: User can select where the internal modules are mapped. If MM bit in
the SCIMMCR register is 1, then the internal modules are addressed from 0xFFF000 - 0xFFFFFF; If 
MM bit is 0, then the internal modules are addressed from 0x7FF000 - 0x7FFFFF.

After the configuration, the batch file will generate three files: ptdemo.h and load_gmd.scp 
in the directoy of "Demo" and CPU32.dbg in the "sds_cfg" directory. "ptdemo.h" is the header file
of the demo. "CPU32.dbg" contains SDS scprit code to initialize the environment and system clock.
"load_gmd.scp" is the SDS script file to load the corresponding GMD images for the revison and 
algorithm selected. 

TIPS: 
- If there are no "ptdemo.h", "CPU32.dbg" and "load_gmd.scp" in the directory, please run the 
"config.bat" for the first step. 
- Please check "ptdemo.h", "CPU32.dbg" and "load_gmd.scp" if you have not run "config.bat" first.
Make sure the default configuration in these files is that you desired. It is a good idea that
always run "config.bat" first to make sure correct configuration selected.
- After running "config.bat", please run "ptdemo.bat" to generate the new ELF file and map file in
the output directory.
- All the intermediate files will be generated in the temp directory.
- Run "clean.bat" to clean up the "temp" directory and "ptdemo" directory.
- The included ptdemo.elf is generated for RevF, Release 5.1, 16 MHz system clock and 512 timer
counter clock division ratio with serial port display enabled.

2. Display Programming Status and Results via Serial Port

1) Hyperterminal settings: 
Connection: correct COM port, 9600 Baud, 8 Data bits, 1 Stop bit, No parity, No flow control.
ASCII setup: make sure "Append line feeds to incoming line ends" and "Wrap lines that exceed
terminal width" are checked.

Note: The Hyperterminal application "SDS_PTDEMO.ht" in the directory of "Demo" is
ready to use. Just double click it to invoke the hyperterminal.

2) M68F375 Modular Platform Board (M68MPFB1632) RS232 Connection:

* Using RS232 Port 1 (9-Pin) on M68MPFB1632:
J23 Pin1 - J17 Pin7 (RxD1)
J23 Pin3 - J17 Pin8 (TxD1)

* Using RS232 Port 2 (25-Pin) on M68MPFB1632:
J23 Pin2 - J17 Pin7 (RxD1)
J23 Pin4 - J17 Pin8 (TxD1)

Config W20 and W23 as DCE. 
W20 and W23 - Jumpers between 1-2, 3-4, ...., and 15-16.
(Refer to the User's Manual for M68MPFB1632 Modular Platform Board.)

No Null Modem required between RS232 on MPB board and RS232 port on host computer.
