/*
C_Array file 'gmd_cpu32_cmf_300_A60_160.c' generated on Mon Apr 23 10:28:41 2001

     The GM Driver's version: 3.00

     The part descriptor will be generated:
          Array Base Address: 0x00000000
          BDM Mode          : 0      (0: Non_BDM   1: BDM)

     The program algorithm descriptor will be generated:
          Algorithm version : 60
          Value of register SYNCR    : 0x7000
          System Clock(MHz) : 16.0
          Max Program Pulses: 48000

     The erase algorithm descriptor will be generated:
          Algorithm version : 60
          Value of register SYNCR    : 0x7000
          System Clock(MHz) : 16.0
          Max Erase Pulses  : 1000

     The compare data will be generated:
*/

unsigned int CPU32CMF300[]=
{

     /* The offset of structure        */
      0x00080024
     ,0x007C00D4


     /* data of structure tCMF_PART */
     ,0x00FFF800
     ,0x00FFF804
     ,0x00FFF80C
     ,0x00000000
     ,0x00000000
     ,0x00000000
     ,0xFF000000


     /* data of structure tCMF_PROGRAM_DATA */
     ,0x70000000
     ,0x10540000
     ,0x10540000
     ,0x10540000
     ,0x10540000
     ,0x10100000
     ,0x10100000
     ,0x10100000
     ,0x10100000
     ,0xFFFFFFFF
     ,0x0C200D20
     ,0x0E200F20
     ,0x04200520
     ,0x06200720
     ,0xFFFF0004
     ,0x00040004
     ,0x00040014
     ,0x00140014
     ,0xFFFFFFFF
     ,0x00000000
     ,0x00000000
     ,0x0000BB80


     /* data of structure tCMF_ERASE_DATA */
     ,0x70000000
     ,0x10200000
     ,0x10200000
     ,0x10200000
     ,0x10200000
     ,0x10200000
     ,0x10200000
     ,0x10200000
     ,0x10200000
     ,0xFFFFFFFF
     ,0x0C000D00
     ,0x0E000F00
     ,0x04000500
     ,0x06000700
     ,0xFFFF0001
     ,0x00010001
     ,0x00010001
     ,0x00010001
     ,0xFFFFFFFF
     ,0x80808080
     ,0x80808000
     ,0x000003E8


     /* data of structure tCMF_COMP_DATA */
     ,0x00000000
     ,0x00000000
     ,0x00000000


     /* the version string */
     ,0x43505533
     ,0x32434D46
     ,0x33303036
     ,0x30313630

};/* the version string is: CPU32CMF30060160 */
/* total size of data is: 240 = 8 + 216 + 16
   (offset + data + version string) */