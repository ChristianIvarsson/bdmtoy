/*************************************************************************
 *           Copyright (C) 2001 by Motorola.  All rights reserved.       *
 *************************************************************************
 *                                                                       *
 *   Motorola reserves the right to make changes without further notice  *
 *   to any product herein to improve reliability, function or design.   *
 *   Motorola does not assume any liability arising out of the           *
 *   application or use of any product, circuit, or software described   *
 *   herein; neither does it convey any license under its patent rights  *
 *   nor the rights of others.                                           *
 *                                                                       *
 *   Motorola products are not designed, intended, or authorized for     *
 *   use as components in systems intended for surgical implant into     *
 *   the body, or other applications intended to support life, or for    *
 *   any other application in which the failure of the Motorola product  *
 *   could create a situation where personal injury or death may occur.  *
 *                                                                       *
 *   Should Buyer purchase or use Motorola products for any such         *
 *   unintended or unauthorized application, Buyer shall idemnify and    *
 *   hold Motorola and its officers, employees, subsidiaries,            *
 *   affiliates, and distributors harmless against all claims costs,     *
 *   damages, and expenses, and reasonable attorney fees arising out     *
 *   of, directly or indirectly, any claim of personal injury or death   *
 *   associated with such unintended or unauthorized use, even if such   *
 *   claim alleges that Motorola was negligent regarding the design      *
 *   or manufacture of the part.                                         *
 *                                                                       *
 *   Motorola and the Motorola logo* are registered trademarks of        *
 *   Motorola Ltd.                                                       *
 *                                                                       *
 *************************************************************************

 *************************************************************************
 *                                                                       *
 *              Motorola's CDR MoneT Flash for CPU32 (CMFI)              *
 *                          General Market Driver                        *
 *                        Demo with GMD in C-array Images                *
 *                                                                       *
 * FILE NAME     :  demo.c                                               *
 * VERSION:      :  0.10                                                 *
 * DATE          :  22 March 2001	                                     *
 *                                                                       * 
 *************************************************************************/
 
/******************************* CHANGES *********************************
 0.13	2001.03.22  Flash Team		Initial version
 *************************************************************************/
#include <gmd_types.h>
#include <gmd_cpu32.h>

#define DEMO_PASS   0x00
#define DEMO_FAIL   0xFF

// list c-array name for the c-array format of GMD driver and GMD data object 
extern unsigned int CPU32CMF300[];
extern const unsigned int gmd_pi[];
extern const unsigned int gmd_pe[];
extern const unsigned int gmd_pp[];
extern const unsigned int gmd_bc[];
extern const unsigned int gmd_pv[];
extern const unsigned int gmd_cs[];

void CallBack( void );


UINT8 main(void)
{
    pCMF_PART           cmfPart         = (pCMF_PART)         0;
    pCMF_ERASE_DATA     eraseData       = (pCMF_ERASE_DATA)   0;
    pCMF_PROGRAM_DATA   programData     = (pCMF_PROGRAM_DATA) 0;
    pCMF_COMP_DATA      compData        = (pCMF_COMP_DATA)    0;
    
    pPARALLELINIT       ParallelInit    = (pPARALLELINIT)     gmd_pi;
    pPARALLELERASE      ParallelErase   = (pPARALLELERASE)    gmd_pe;
    pBLANKCHECK         BlankCheck      = (pBLANKCHECK)       gmd_bc;
    pPARALLELPROGRAM    ParallelProgram = (pPARALLELPROGRAM)  gmd_pp;
    pPARALLELVERIFY     ParallelVerify  = (pPARALLELVERIFY)   gmd_pv;
    pCHECKSUM           CheckSum        = (pCHECKSUM)         gmd_cs;

    UINT16 *gmd_data = (UINT16*) CPU32CMF300;

    UINT8   sum, enabledBlocks[CMF_MODULES];
    VUINT8  returnCode; 						// defined as volatile variable for avoiding from being optimized
    											// and user can see it in debug mode

    UINT32  buffer[TOTAL_BLOCKS*PAGE_SIZE/4];   // source program buffer, size=8(blocks) * 16(page size in word) * 1 (pagesets)
    UINT32  i, dest, size;
                   
	// anchor GMD data objects from CPU32CMF300 (c-array format)
    if(gmd_data[GMDIO_OFFSET_PART_DESCRIPTION/2] != 0xFFFF)
        cmfPart = (pCMF_PART) ((UINT32)CPU32CMF300 + gmd_data[GMDIO_OFFSET_PART_DESCRIPTION/2]);

    if(gmd_data[GMDIO_OFFSET_PROGRAM_DATA/2] != 0xFFFF)
        programData = (pCMF_PROGRAM_DATA) ((UINT32)CPU32CMF300 + gmd_data[GMDIO_OFFSET_PROGRAM_DATA/2]);

    if(gmd_data[GMDIO_OFFSET_ERASE_DATA/2] != 0xFFFF)
        eraseData = (pCMF_ERASE_DATA) ((UINT32)CPU32CMF300 + gmd_data[GMDIO_OFFSET_ERASE_DATA/2]);

    if(gmd_data[GMDIO_OFFSET_COMP_DATA/2] != 0xFFFF)
        compData = (pCMF_COMP_DATA) ((UINT32)CPU32CMF300 +  gmd_data[GMDIO_OFFSET_COMP_DATA/2]);


   /*========================= Initialize Part =========================*/
    cmfPart->enabledBlocks[CMF_MODULE_A] = 0xFF;	// enable all Blocks in module A
    
    cmfPart->enableBDM = FALSE;                 	// don't enter BDM after function exit
   
    // call ParallelInit
    returnCode = (*ParallelInit)( cmfPart );
    if(returnCode != CMF_OK)
		return ( returnCode );


    /*==================Erase all blocks and shadow rows=================*/
    // erase all blocks and shadow
    enabledBlocks[CMF_MODULE_A] = 0xFF;
    
    // ParallelErase(cmfPart, eraseData, enabledBlocks, CallBack );
    returnCode = (*ParallelErase)( cmfPart, eraseData, enabledBlocks, CallBack );
    if(returnCode != CMF_OK) 
		return ( returnCode );
		    
    
    /*===============Blank check all blocks and shadow row in module A==============*/
    // Blank check main array of module A
    dest = 0 + cmfPart->cmf[CMF_MODULE_A].arrayBase;
    size = BLOCKS_IN_MODULE* BLOCK_SIZE;
    
    // BlankCheck( cmfPart, dest, size, shadow, cmfCompare, CallBack ); 
    returnCode = (*BlankCheck)( cmfPart, dest, size, MAIN_ARRAY, compData, CallBack );
    if(returnCode!=CMF_OK)
		return ( returnCode );
    
    // Blank check shadow row of module A
    dest = 0 + cmfPart->cmf[CMF_MODULE_A].arrayBase;
    size = SHADOW_SIZE;
    returnCode = (*BlankCheck)( cmfPart, dest, size, SHADOW_ROW, compData, CallBack );
    if(returnCode!=CMF_OK)
		return ( returnCode );
    

    /*======Program all main arrays and shadow row of module A to 0s================*/
    // initialize the source buffer for program, set them all to 0s
    for( i = 0; i < TOTAL_BLOCKS * (PAGE_SIZE / 4); i++)
        buffer[i]=0x00000000;   					// set source buffer to all 0s

    // select all blocks in module A
    enabledBlocks[CMF_MODULE_A] = 0xFF;
    
    // program all cmf array of module A from 0xFFFFFFFF to 0x00000000 (call ParallelProgram 512 times, one pageset each time)
    for(i = 0; i < MAX_PAGESET_NUM; i++)
    {
        // ParalleProgram( cmfPart, programData, enabledBlocks, (UINT32)source, offset, pagesetNum, shadow, CallBack );
        returnCode = (*ParallelProgram)( cmfPart, programData, enabledBlocks, (UINT32)buffer, PAGE_SIZE*i, 1, MAIN_ARRAY, CallBack );
        if(returnCode!=CMF_OK)
            return ( returnCode );
    }

    // select shadow row of module A
    enabledBlocks[CMF_MODULE_A] = 0x80;

    // program shadow row of module A from 0xFFFFFFFF to 0x00000000 (call ParallelProgram 1 times, 4 pagesets once)
    returnCode = (*ParallelProgram)( cmfPart, programData, enabledBlocks, (UINT32)buffer, 0, MAX_PAGESET_NUM_OF_SHADOW, SHADOW_ROW, CallBack );
    if(returnCode!=CMF_OK)
        return ( returnCode );
    

    /*========Parallel verify all array and shadow of module A after program========*/
    // the source program buffer is still buffer
    // select all blocks in module A
    enabledBlocks[CMF_MODULE_A] = 0xFF;

    // verify all cmf array (call ParallelVerify 512 times, one pageset each time)
    for(i = 0; i < MAX_PAGESET_NUM; i++)
    {
        // ParallelVerify ( cmfPart, enabledBlocks, (UINT32)source, offset, pagesetNum, shadow, cmfCompare, CallBack ); 
        returnCode = (*ParallelVerify)( cmfPart, enabledBlocks, (UINT32)buffer, PAGE_SIZE*i,  1, MAIN_ARRAY, compData, CallBack);
        if(returnCode != CMF_OK)
            return ( returnCode );
    }

    // select module A shadow row
    enabledBlocks[CMF_MODULE_A] = 0x80;

    // verify shadow row of module A (call ParallelVerify 1 times, 4 pagesets once)
    returnCode = (*ParallelVerify)( cmfPart, enabledBlocks, (UINT32)buffer, 0, MAX_PAGESET_NUM_OF_SHADOW, SHADOW_ROW, compData, CallBack);
    if(returnCode != CMF_OK)
        return ( returnCode );
        

    /*================Check sum of main array and shadow row============*/
    // check sum of module A, dest=0, size=8*32KB
    dest = 0 + cmfPart->cmf[CMF_MODULE_A].arrayBase;
    size = BLOCK_SIZE * BLOCKS_IN_MODULE;
    
    // CheckSum ( cmfPart, dest, size, shadow, sum, CallBack );    
    returnCode = (*CheckSum)( cmfPart, dest, size, MAIN_ARRAY, &sum, CallBack );
    if(returnCode != CMF_OK)
        return ( returnCode );

    // The sum value should be just 0
    if( sum != 0x00 )
        return ( returnCode = DEMO_FAIL );
        

    // check sum of shadow row of module A
    dest = 0 + cmfPart->cmf[CMF_MODULE_A].arrayBase;
    size = SHADOW_SIZE;
    
    // CheckSum ( cmfPart, dest, size, shadow, sum, CallBack );    
    returnCode = (*CheckSum)( cmfPart, dest, size, SHADOW_ROW, &sum, CallBack );
    if(returnCode != CMF_OK)
        return ( returnCode );

    // The sum value should be just 0
    if( sum != 0x00 )
        return ( returnCode = DEMO_FAIL );

            
    // DEMO PASSED  
    return DEMO_PASS;
}


void CallBack( void )
{
}


