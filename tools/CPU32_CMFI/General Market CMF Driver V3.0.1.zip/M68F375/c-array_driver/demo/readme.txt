********************************************************************************
                      Readme of GMD Demo for M68F375

                   Software Center, Motorola China
                   
   VERSION:      :  1.0
   DATE          :  April 04, 2001
   AUTHOR        :  Flash Team
********************************************************************************

********************************************************************************
 Motorola reserves the right to make changes without further notice to any
 product herein to improve reliability, function or design. Motorola does not
 assume any liability arising out of the application or use of any product,
 circuit, or software described herein; neither does it convey any license
 under its patent rights nor the rights of others. Motorola products are not
 designed, intended, or authorized for use as components in systems intended for
 surgical implant into the body, or other applications intended to support life,
 or for any other application in which the failure of the  Motorola product
 could create a situation where personal injury or death may occur. Should
 Buyer purchase or use Motorola products for any such unintended or
 unauthorized application, Buyer shall idemnify and hold Motorola and its
 officers, employees, subsidiaries, affiliates, and distributors harmless
 against all claims costs, damages, and expenses, and reasonable attorney fees 
 arising out of, directly or indirectly, any claim of personal injury or death
 associated with such unintended or unauthorized use, even if such claim alleges
 that Motorola was negligent regarding the design or manufacture of the part.
 Motorola and the Motorola logo* are registered trademarks of Motorola Ltd.
********************************************************************************

****************************** CHANGES HISTORY *********************************
  1.0   April 04, 2001	Cloud Li	Initial Version
  1.1	April 05, 2001	Cloud Li	Update for m4 configuration
********************************************************************************

1 Overview

This is a demo on General Maket Dirver for M68F375. Usage of all 
GMD APIs are included in it. Detailed features are listed below.

 *) Demonstrate ParallelInit function;
 *) Demonstrate ParallelErase function;
 *) Demonstrate BlankCheck function, involving checking main array and shadow; 
 *) Demonstrate ParallelProgram function, involving programming main array and shadow;
 *) Demonstrate ParallelVerify function, involving Verifying main array and shadow;
 *) Demonstrate CheckSum function,involving calculating main array and shadow;

After the demo has been finished, the result in flash module is listed below:
    main array:
        Module A is all 0x000000000s.
       
    shadow:
        Module A is all 0x000000000s.
        

2 GMD Demo for M68F375

2.1 File Structure
c-array_driver (directory)
|
+---demo
|       |demo.lin
|       |demo.bat
|       |clean.bat
|       |demo.c
|       |crt0.s
|       |asstep.ini
|       |readme.txt    
|       |Shortcut to bdm68k.lnk
|       +output
|       |     |demo.elf
|       |     |memory.map
|       +sds_cfg
|       |     |CPU32.dbg
|       +temp
|       |     |*.err
|       |     |*.wrn
|       |     |*.obj
|       |     |*.l
+---gmd_driver
|       |gmd_cpu32_cmf_300_Axx_xxx.c
|       |gmd_pi_bin.c
|       |gmd_pe_bin.c
|       |gmd_bc_bin.c
|       |gmd_pp_bin.c
|       |gmd_pv_bin.c
|       |gmd_cs_bin.c
+---gmd_include
|       |gmd_cpu32.h
|       |gmd_types.h
|  
+---m4src
        |config.bat
        |CPU32.dbg.m4
        |demo.bat.m4
        |getercde.com
        |m4.exe
        |util.m4
        
The above chart is the file set organization of GMD demo for M68F375.
    1) Root directory "c-array_driver" is the working directory; 
    2) "Demo" consists of demo case files (*.c, *.ini, *.s, *.lin, *.bat, readme.txt and shortcut file);
    3) "gmd_driver" is the directory of GMD Driver file; 
    4) "gmd_include" consists of header files for demo compiling;
    5) "m4src" consistes of m4 tools and m4 source files(*.m4) for configuration;
            
2.2 Configuration
    1) Before generating ELF file, the environment should be configured properly;
    Make sure you have DIAB C installed and configured properly;
    Check the environment, especially the path of DIAB C.
    
    2) A batch file is provided to make the normal configuration more easily. The batch 
	file is "config.bat" in the directory "m4src". Note that the batch file will use 
	tools of getercde.com and m4.exe, which are also in the "m4scr" directory.
	Please make sure that the these files exist before using the batch file. 
	
	3) User can select release algorithm, system clock and module mapping. After the configuration,
	the batch file will generate two files: "demo.bat" in the directoy of "Demo" and "CPU32.dbg" in 
	the "sds_cfg" directory. "demo.bat" is used for compiling the demo. "CPU32.dbg" contains SDS scprit 
	code to initialize the environment and system clock.
	
	Note: It is recommended that run "config.bat" to configure the environment for the first step.

    3) Make sure the correct c-array data object "gmd_cpu32_cmf_300_Axx_xxx.c" exists under the "gmd_driver"
       directory. The data object can be found in "..\data_generator\prebuiltdata" or generated by running the
       data generator.

2.3 Generate ELF File of Demo Case
    The batch command file "demo.bat" contained in the directory "demo"
    is used to generate the demo case. 

2.4 Outputs
    1) The typical output file is demo.elf and demo.map.They are stored in the ".\demo\output" directory;
    2) Other files like *.wrn, *.o, *.l and *.err are intermediate files during generating ELF file. 
       They are stored in ".\demo\temp" directory.

3 Run Demo Manually
3.1 Environment
    Windows NT4(sp5), SDS 7.4
    Wiggler on LPT1.

3.2 Procedures of Running Demo Case Manually
In the "demo"directory,"Shortcut to bdm68k.lnk" and "asstep.ini" are
used to run demo manually for M68F375.

    1.Right mouse click on the short cut file, for example 
      "Shortcut to bdm68k.lnk", then select "properties" in the menu, select 
      "shortcut", modify "target" to correct path and right program, and modify
      "start in" to be the same directory as this 
      "Shortcut to bdm68k.lnk" resided;

    2.Launch the shortcut file and debug file "demo.elf";

    3. Now set the breakpoint and run the demo.
