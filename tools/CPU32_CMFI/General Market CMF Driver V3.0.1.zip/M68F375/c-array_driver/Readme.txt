This folder contains the c-array driver images and a demo illustrating how to use them.

Subdirectories:
1) demo - a demo demonstrating the usage of all driver APIs.
2) gmd_driver - c-array drivers images which include .c files for all APIs and the data object. 
3) gmd_include - header files for applications development.
